import psycopg2
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import os
import torch
from langchain_community.llms import LlamaCpp
#from langchain.llms import LlamaCpp
from langchain_core.prompts import ChatPromptTemplate
import datetime
from config import DB_CONFIG
import pickle
import os



# ** Carregar o Modelo SQLCoder **
model_name = "defog/llama-3-sqlcoder-8b"
tokenizer = AutoTokenizer.from_pretrained(model_name)
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,  
    bnb_4bit_use_double_quant=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.float16
)

# Verificar a memória disponível na GPU
available_memory = torch.cuda.mem_get_info()[0] if torch.cuda.is_available() else 0

if available_memory > 20e9:  # Se tiver pelo menos 20GB de VRAM
    print("🔹 GPU com memória suficiente! Carregando em float16...")
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        trust_remote_code=True,
        torch_dtype=torch.float16,
        device_map="auto",
        use_cache=True,
        offload_folder="offload",  # Pasta para armazenar camadas descarregadas
        offload_state_dict=True,
    )
else:
    print("⚠️ Pouca memória na GPU! Carregando em 4-bit com quantização...")
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        trust_remote_code=False,
        quantization_config=bnb_config,  
        device_map="auto",
        use_cache=True,
        offload_folder="offload",  # Pasta para armazenar camadas descarregadas
        offload_state_dict=False,
    )

print(torch.cuda.memory_allocated() / 1024**2, "MiB alocados inicialmente")
print(torch.cuda.memory_reserved() / 1024**2, "MiB reservados")

# ** Carregar o Modelo LLamaCpp para NLP **
n_gpu_layers = -1  
n_batch = 512  
n_ctx = 2048 

llm = LlamaCpp(
    model_path="../models/model_Q5_K_S.gguf",
    temperature=0,
    max_tokens=500,  
    n_ctx=n_ctx,
    top_p=1,
    n_threads=8,
    verbose=True,
    f16_kv=True,
    n_gpu_layers=0,
    n_batch=n_batch,
    chat_format="chatml"
)


# ** Função para Gerar a Query SQL **
def generate_query(question,patient_id=None):

    
    if "paciente" in question.lower() or "doente" in question.lower() or patient_id:
        question_with_id = f"{question} for patient with ID {patient_id}"
    else:
        question_with_id = question
    prompt = f"""<|begin_of_text|><|start_header_id|>user<|end_header_id|>

Generate a SQL query to answer this question: `{question_with_id}`
    
    ### Instructions
    - Given an input question, create a syntactically correct query to run, then look at the results of the query and return the answer.
    - If the question is unrelated to the medical or clinical database context (e.g., greetings, general knowledge, jokes, or chit-chat), respond with: "I am a medical database assistant. Please ask about      consultations, exams, or patients."
    - Never query for all the columns from a specific table; only ask for the relevant columns given the question.
    - Only return the columns the user asks for; do not give any additional ID column that the user does not ask for explicitly.
    - Do not add ORDER BY in the query if the user has not explicitly asked to order it.
    - If you cannot answer the question with the available database schema, return 'I do not know.'
    - Make sure that you never return two columns with the same name, especially after joining two tables. You can differentiate the same column name by applying column_name + table_name.
    - DO NOT make any DML statements (INSERT, UPDATE, DELETE, DROP, etc.) to the database.
    - Use the table `exames` when the user asks about whether an exam was billed (`facturado`) or verified (`verificado`).
    - Use the table `dexames` when the user asks about details like exam date, service, or report (`dataexame`, `servico`, `relatorio`, etc.).
    - If you are fetching data from a table only then use its columns to filter out the data.
    - You MUST double-check your query before executing it. If you get an error while executing a query, rewrite the query and try again.
    - When filtering by or formatting a DATE column (e.g., dta_consulta), do NOT use TO_DATE(). Use it directly.
    - To display a DATE in 'DD/MM/YYYY' format, use TO_CHAR(dta_consulta, 'DD/MM/YYYY').
    - For comparisons, use CURRENT_DATE or DATE 'YYYY-MM-DD'.
    - When filtering by time-of-day (e.g., "morning", "afternoon", "evening"), first convert the time in seconds to hour-of-day using (hora_consulta / 3600), and apply the appropriate range in hours (e.g., afternoon = 12 to 18).
    - All time values are stored in seconds; if the user asks about time or duration, convert the result to hh:mm format using SEC_TO_TIME().
    - Use the table `con_marcacoes` when the user asks about future or present appointments (e.g., "hoje", "amanhã", or a future date).
    - Use the table `con_registadas` only when the user asks about past consultations (e.g., "tive", "ontem", or a past date).
    - For "hoje", compare dates using CURRENT_DATE; for "amanhã", use CURRENT_DATE + INTERVAL 1 DAY.
    - The column `cod_med_esp` can refer to either a doctor or a specialty depending on the value of `tip_agenda`:
        - If `tip_agenda = 'M'`, then `cod_med_esp` refers to a doctor and should be matched with `num_ord_medico`.
        - If `tip_agenda = 'E'`, then `cod_med_esp` refers to a specialty and should be matched with `cod_especialidade`.
    - Always check `tip_agenda` before deciding how to interpret `cod_med_esp` in a WHERE clause or JOIN.
    - Whenever the table already contains the column `cod_medico`, use it directly to filter or retrieve information about doctors — do not join with the `con_med_esp` table.
    - Only use the `con_med_esp` table when working with a `cod_med_esp` field (e.g., in `con_marcacoes` or `con_registadas`) and when it's necessary to determine whether the value refers to a doctor (`tip_agenda = 'M'`) or a specialty (`tip_agenda = 'E'`).
    - Do not assume a column exists in a joined table — check the schema and use the correct table alias.
    - If a column is needed but not present in the primary table, verify whether it exists in a related table before joining.
    ### Examples
    
    
    #### Question:
    Para que médico está marcada a próxima consulta do dia 2025-05-08 do paciente com ID 5992875?
    
    #### Explanation:
    This query retrieves the doctor assigned to a patient's appointment on a specific date.
    Since the appointment uses `tip_agenda = 'M'`, the column `cod_med_esp` refers to a doctor. 
    We use a join with `con_med_esp` to obtain the `cod_medico`, and then join with `sys_medicos` to get the doctor's name. 
    The `ORDER BY` ensures that appointments are sorted chronologically, and although `LIMIT 1` may be used to retrieve a single result, in general, avoid using it unless the question explicitly asks for the "first" or "next".
    
    #### SQL:
    SELECT s.num_ord_medico, s.nome
    FROM con_marcacoes cm
    JOIN con_med_esp cme ON cm.cod_med_esp = cme.cod_med_esp
    JOIN sys_medicos s ON cme.cod_medico = s.num_ord_medico
    WHERE cm.num_sequencial = 5992875
      AND cm.tip_agenda = 'M'
      AND cm.dta_consulta = '2025-05-08'
    ORDER BY cm.dta_consulta;
    
    ---
    
    #### Question:
    Qual é a especialidade da próxima consulta do dia 2025-05-08 do paciente com ID 942725?
    
    #### Explanation:
    This query retrieves the clinical specialty for the patient's next appointment on the specified date.
    The `tip_agenda = 'E'` indicates that `cod_med_esp` refers to a specialty.
    We join with `con_med_esp` to extract `cod_especialidade`, and then join with `sys_especialidades` to obtain the description.
    The `ORDER BY` ensures results are sorted by date.
    
    #### SQL:
    SELECT cm.num_sequencial, s.cod_especialidade, s.des_especialidade
    FROM con_marcacoes cm
    JOIN con_med_esp cme ON cm.cod_med_esp = cme.cod_med_esp
    JOIN sys_especialidades s ON cme.cod_especialidade = s.cod_especialidade
    WHERE cm.num_sequencial = 942725
      AND cm.tip_agenda = 'E'
      AND cm.dta_consulta = '2025-05-08'
    ORDER BY cm.dta_consulta;
    
    ---
    #### Question:
    What are the clinical notes written by the doctor with ID 33844?
    
    #### Explanation:
    The table `con_diarios` already contains the column `cod_medico`, which directly refers to the doctor's `num_ord_medico`.
    There is no need to join with `con_med_esp`, because the doctor's code is already available in the table.
    
    #### SQL:
    SELECT d.diario
    FROM con_diarios d
    WHERE d.cod_medico = 33844;
    
    
    #### Question:
    Quais foram os serviços com mais exames realizados este mês?
    
    #### Explanation:
    When selecting columns, always retrieve them from the table where they exist.
    For example, servico exists in the dexames table, not in exames.
    Do not assume a column exists in a joined table — check the schema and use the correct table alias.
    If a column is needed but not present in the primary table, verify whether it exists in a related table before joining.
    This query counts the number of exams performed this month, grouped by the servico (service).
    The column servico is only present in the dexames table, not in exames, so we must select it from dexames using alias d.servico.
    We join with the exames table to include only valid exam entries (if needed), and we filter by the current month and year using EXTRACT() on d.dataexame.
    #### SQL:
    SELECT d.servico,
           COUNT(*) AS num_exames
    FROM dexames d
             JOIN exames e ON d.numexame = e.numexame
    WHERE EXTRACT(MONTH FROM d.dataexame) = EXTRACT(MONTH FROM CURRENT_DATE)
      AND EXTRACT(YEAR FROM d.dataexame) = EXTRACT(YEAR FROM CURRENT_DATE)
    GROUP BY d.servico
    ORDER BY num_exames DESC NULLS LAST;
    
    
    DDL statements:
    
    -- Tabela: con_marcacoes 
    -- Contém consultas futuras (ou presentes). A data está no formato DATE.
    -- Usa-se diretamente nas comparações (ex: c.dta_consulta > CURRENT_DATE).
    -- Para exibição formatada, usa TO_CHAR(c.dta_consulta, 'DD/MM/YYYY').
    -- cod_med_esp liga a médico ou especialidade, dependendo de tip_agenda.
    
    CREATE TABLE con_marcacoes (
        num_sequencial SERIAL , --numero identificador do paciente
        cod_med_esp INTEGER NOT NULL, -- relacao medico ou especialidade - tip_agenda = M (vai ao medico) / E - sysespecialidade)  (
        tip_consulta VARCHAR(10), -- P - primeira consulta ; S - Ou consulta Subsequente
        dta_consulta INTEGER, --data para a qual a consulta está agendada
        hora_consulta INTEGER NOT NULL, -- hora agendada para a consulta em segundos
        cod_sala VARCHAR(10), --sala onde está agendada realizado
        cod_especialidade INTEGER, --especialidade liga com a sys_especialidades
        tip_agenda CHAR(1), -- M - Médico, E - Especialidade
        PRIMARY KEY (num_sequencial, dta_consulta, hora_consulta)
    );
    
    -- Tabela: con_med_esp
    -- Relação entre médicos e especialidades. Utilizada em marcações.
    -- cod_medico refere-se a sys_medicos; cod_especialidade a sys_especialidades.
    
    CREATE TABLE con_med_esp (
        cod_med_esp INTEGER PRIMARY KEY, -- cod_med_esp da tabela con_marcacoes
        cod_especialidade INTEGER NOT NULL, -- cod_especialidade da sys_especialidades
        cod_medico INTEGER NOT NULL -- num_ord_medico da sys_medicos
    );
    
    -- Tabela: sys_medicos
    -- Lista dos médicos disponíveis, identificados pelo número de ordem (num_ord_medico).
    CREATE TABLE sys_medicos (
        num_ord_medico INTEGER PRIMARY KEY, --numero da ordem do médico
        nome TEXT -- nome
    );
    
    
    -- Tabela: sys_especialidades
    -- Lista de especialidades clínicas. cod_especialidade é usado em marcações e exames.
    
    create table sys_especialidades (
        cod_especialidade integer primary key, --codigo
        des_especialidade varchar(400) --descricao
    );
    
    -- Tabela: con_registadas ( consultas já realizadas)
    -- Contém consultas já realizadas (passadas). A data está em formato DATE.
    -- Usa-se diretamente em comparações ou formatação com TO_CHAR.
    -- cod_med_esp funciona como em con_marcacoes, com base em tip_agenda.
    
    CREATE TABLE con_registadas (
        episodio INTEGER PRIMARY KEY, --numero indetificador da visita do paciente (unico)
        num_sequencial INTEGER, -- numero identificador do paciente
        cod_med_esp INTEGER NOT NULL, -- relacao medico ou especialidade - tip_agenda = M (vai ao medico) / E - sysespecialidade)
        tip_consulta VARCHAR(10), -- P - primeira consulta ; S - Ou consulta Susequente
        dta_realizacao DATE, --data da consulta
        hora_realizacao INTERGER, -- hora da consulta já realizada em segundos
        cod_sala VARCHAR(10),  --sala onde é realizado
        cod_especialidade INTEGER, --especialidade liga com a sys_especialidades
        tip_agenda CHAR(1) -- M - Médico, E - Especialidade
    );
    
    -- Tabela: dpedidos
    -- Pedidos de exames efetuados durante episódios clínicos. Liga-se a pacientes e ao episódio da consulta.
    -- Contém informação sobre serviço, modalidade, data do pedido, e estado de agendamento/realização.
    
    CREATE TABLE dpedidos (
        numpedido INTEGER PRIMARY KEY, -- numero identificador do pedido
        episodio INTEGER, --numero indetificador da visita do paciente
        modulo VARCHAR(50), -- 'CON'; 'INT', 'URG', 'BLO', 'HDI'
        designamodulo VARCHAR(100), --designacao do modulo: 'Consulta', 'Internamento', 'Urgência', 'Bloco', 'Hospital de Dia'
        idser VARCHAR(20), -- serviço executante ('CARD','PNEUMO','GASTRO')
        servico VARCHAR(100), -- designação do serviço: 'Cardiologia, Pneumologia, Gastro')
        datapedido DATE, -- data de realização do pedido
        posto VARCHAR(20), -- posto para o qual vai ser agendado
        num_sequencial INTEGER,  --numero indetificador da visita do paciente
        datanascimento DATE, -- data de nascimento
        sexo CHAR(1), -- sexo ( 1- Masculino ; 2- Feminino)
        modalidade VARCHAR(50), -- modalidade de execução do exame: 'PNEUMO','CH' - Holter, 'ECG','CM' - MAPA,'GASTRO' (é um agrupador de atos e corresponde à modalidade da tabela tabigif)
        numexame INTEGER, -- preenchido quando há um exame realizado para este pedido
        marcado VARCHAR(1), -- Estado do pedido 0 - pedido, 1 - agendado, 2- rececionado, 3- em execução, 4 - realizado
        fechado VARCHAR(1), -- 0 não terminado, 1 fechado
        segura VARCHAR(1), -- nulo: exame no estado correto; > 8 - anulado ou cancelado
        utiliza VARCHAR(50), -- num mecanografico do utilziador que agendou o exame
        dataexame DATE -- data de realização do exame(quando realizado)
    );
    
    -- Tabela: pedidos
    -- Atos médicos associados a um pedido (dpedidos). Cada pedido pode conter vários atos (exames).
    -- Usa cod_pedido (ligado a tabigif) e tem ordem para identificar sequência dos atos.
    
    CREATE TABLE pedidos (
        numpedido INTEGER, --identificador do pedido que corresponde ao numpedido da tabela dpedidos
        ordem INTEGER, -- se tiver mais do que um ato medico a realizar são ordenados por aqui
        idser VARCHAR(20), -- serviço executante ('CARD','PNEUMO','GASTRO')
        modalidade VARCHAR(50), -- modalidade de execução do exame: 'PNEUMO','CH' - Holter, 'ECG','CM' - MAPA,'GASTRO' (é um agrupador de atos e corresponde à modalidade da tabela tabigif)
        cod_pedido VARCHAR(50), -- cigif da tabela tabigif e é o codigo identificado do ato medico a realizar
        des_pedido TEXT, -- digif da tabela tabigif e é a descrição do ato medico a realizar
        PRIMARY KEY (numpedido, ordem)
    );
    
    -- Tabela: dexames
    -- Instâncias de exames realizados ou agendados. Relaciona-se com pacientes e pedidos.
    -- Contém dados como data do exame (DATE), serviço, relatório e path para PDF.
    
    CREATE TABLE dexames (
        numexame VARCHAR PRIMARY KEY, -- número identificador do exame
        episodio INTEGER, --numero indetificador da visita do paciente
        modulo VARCHAR(50), -- 'CON'; 'INT', 'URG', 'BLO', 'HDI'
        designamodulo VARCHAR(100), --designacao do modulo: 'Consulta', 'Internamento', 'Urgência', 'Bloco', 'Hospital de Dia'
        idser VARCHAR(20), -- serviço executante ('CARD','PNEUMO','GASTRO')
        servico VARCHAR(100), -- designação do serviço: 'Cardiologia, Pneumologia, Gastro')
        datapedido DATE, -- data de realização do pedido
        posto VARCHAR(20), -- posto para o qual vai ser agendado
        num_sequencial INTEGER,  --numero indetificador da visita do paciente
        datanascimento DATE,  -- data de nascimento
        sexo CHAR(1), -- sexo ( 1- Masculino ; 2- Feminino)
        modalidade VARCHAR(50), -- modalidade de execução do exame: 'PNEUMO','CH' - Holter, 'ECG','CM' - MAPA,'GASTRO' (é um agrupador de atos e corresponde à modalidade da tabela tabigif)
        relatorio TEXT, --texto final do relatorio (normalmente encriptado)
        pathrelatorio TEXT, --link para o pdf do relatorio
        fechado VARCHAR(1), -- 0 não terminado, 1 fechado
        segura VARCHAR(1), -- nulo: exame no estado correto; > 8 - anulado ou cancelado
        utiliza VARCHAR(50), -- num mecanografico do utilziador que realizou o exame
        dataexame DATE -- data de realização do exame(quando realizado)
    );
    
    -- Tabela: exames
    -- Detalhes técnicos dos exames realizados, com código, designação, verificação e faturação.
    -- Liga-se a dexames por numexame e à tabela de atos (tabigif) por codigif.
    
    CREATE TABLE exames (
        numexame VARCHAR, --identificador do exame que corresponde ao numexame da tabela dexames
        versao INTEGER, --se tiver mais do que uma versão começa no valor 1
        ordem INTEGER, --se tiver mais do que um ato medico a realizar são ordenados por aqui
        idser VARCHAR(20), -- serviço executante ('CARD','PNEUMO','GASTRO')
        codigif VARCHAR(20), -- cigif da tabela tabigif e é o codigo identificador do ato medico realizado
        designacaoigif VARCHAR(100), -- digif da tabela tabigif e é a descrição do ato medico realizado
        verificado VARCHAR(1), -- 0 não verificado, 1 verificado, 2- com erro
        facturado VARCHAR(1),--  0 não faturado, 1 faturado, 2- com erro
        PRIMARY KEY (numexame, versao, ordem)
    );
    
    -- Tabela: pacientes
    CREATE TABLE pacientes (
        num_sequencial INTEGER PRIMARY KEY, --numero indetificador da visita do paciente
        nome VARCHAR(20), --nome do doente
        data_nascimento date, -- data de nascimento
        sexo VARCHAR(1), -- sexo ( 1- Masculino ; 2- Feminino)
        num_processo    integer -- numero do processo do paciente
        
        
    );
    -- Tabela: con_diarios
    -- Registos de texto clínico (diários) criados pelo médico durante o episódio da consulta.
    
    CREATE TABLE con_diarios (
        id_diario INTEGER PRIMARY KEY, --numero indetificador do diario
        episodio INTEGER, --numero indetificador da visita do paciente
        diario VARCHAR(4000), -- texto do diário
        cod_medico integer, --num_ordem_medico
        data_diario date -- data de execução do diário
    );
    
    -- Tabela: tabigif
    -- Catálogo de atos médicos possíveis. Define códigos e designações (cigif e digif).
    -- Também identifica o serviço e modalidade a que pertencem os atos.
    
    create table tabigif (
        cigif varchar(6) primary key, -- codigo identificador do ato medico
        idser varchar(6), -- código do serviço executante ('CARD','PNEUMO','GASTRO')
        servico varchar(20), -- descrição do serviço executante ('Cardiologia, Pneumologia, Gastro')
        modalidade varchar(6), -- modalidade agrupadora de atos ('PNEUMO','CH' - Holter, 'ECG','CM' - MAPA,'GASTRO')
        digif varchar(400), -- descrição do ato medico
        tipo_am varchar(1), -- tipo do exame M-MCDTs, A-Análise
        ativo varchar(1) -- Se esta ativo ou não 0-não;1-sim
    );
    
    -- con_med_esp -> sys_medicos
    ALTER TABLE con_med_esp ADD CONSTRAINT fk_medesp_medico FOREIGN KEY (cod_medico) REFERENCES sys_medicos(num_ord_medico);
    
    -- dpedidos -> pacientes
    ALTER TABLE dpedidos ADD CONSTRAINT fk_dpedidos_paciente FOREIGN KEY (num_sequencial) REFERENCES pacientes(num_sequencial);
    
    -- dpedidos -> con_registadas
    ALTER TABLE dpedidos ADD CONSTRAINT fk_dpedidos_episodio FOREIGN KEY (episodio) REFERENCES con_registadas(episodio);
    
    -- pedidos -> dpedidos
    ALTER TABLE pedidos ADD CONSTRAINT fk_pedidos_dpedidos FOREIGN KEY (numpedido) REFERENCES dpedidos(numpedido);
    
    -- pedidos -> atos
    ALTER TABLE pedidos ADD CONSTRAINT fk_pedidos_atos FOREIGN KEY (cod_pedido) REFERENCES tabigif(cigif);
    
    -- dexames -> con_registadas
    ALTER TABLE dexames ADD CONSTRAINT fk_dexames_episodio FOREIGN KEY (episodio) REFERENCES con_registadas(episodio);
    
    -- dexanes -> paciente
    ALTER TABLE dexames ADD CONSTRAINT fk_dexanes_paciente FOREIGN KEY (num_sequencial) REFERENCES pacientes(num_sequencial);
    
    -- dexames -> exames
    ALTER TABLE exames ADD CONSTRAINT fk_exames_dexames FOREIGN KEY (numexame) REFERENCES dexames(numexame);
    
    -- exames -> atos
    ALTER TABLE exames ADD CONSTRAINT fk_exames_atos FOREIGN KEY (coDIGIF) REFERENCES tabigif(cigif);
    
    -- diarios -> exames
    ALTER TABLE con_diarios ADD CONSTRAINT fk_diario_consulta FOREIGN KEY (episodio) REFERENCES con_registadas(episodio);
    
    -- con_med_esp -> sys_medicos
    ALTER TABLE con_diarios ADD CONSTRAINT fk_cod_medico FOREIGN KEY (cod_medico) REFERENCES sys_medicos(num_ord_medico);
    
    -- con_med_esp -> sys_especialidades
    ALTER TABLE con_med_esp ADD CONSTRAINT fk_cod_med_especialidade FOREIGN KEY (cod_especialidade) REFERENCES sys_especialidades(cod_especialidade);
    
    
    
    <|eot_id|><|start_header_id|>assistant<|end_header_id|>
    
    
    The following SQL query best answers the question `{question}`:
    ```sql
    """

    inputs = tokenizer(prompt, return_tensors="pt").to("cuda" if torch.cuda.is_available() else "cpu")
    generated_ids = model.generate(
        **inputs, num_return_sequences=1, eos_token_id=tokenizer.eos_token_id, 
        pad_token_id=tokenizer.eos_token_id, max_new_tokens=400, do_sample=False, num_beams=1, temperature=0.0, top_p=1
    )
    outputs = tokenizer.batch_decode(generated_ids, skip_special_tokens=False )#True


    query = outputs[0].split("```sql")[1].split(";")[0].strip()
    print(query)
    
    return query
    
# ** Função para Executar a Query no PostgreSQL **
def execute_sql_query(query):
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cursor = conn.cursor()
        cursor.execute(query)
        result = cursor.fetchall()
        print(result)
        cursor.close()
        conn.close()
        return result if result else []
    except Exception as e:
        return f"Erro ao executar query: {str(e)}"



# ** Função para Converter SQL para Linguagem Natural **
def sql_result_to_natural_language(llm,question, sql_query, result):

    #  **Simulação de um resultado SQL**
    #question = "Dá-me o último exame deste paciente."
    #sql_query = "SELECT id_exame, tipo_exame, data_realizacao, resultado, medico FROM exames WHERE id_paciente = 2 ORDER BY data_realizacao DESC LIMIT 1"
    #sql_result = [(5, 'ECG (Eletrocardiograma)', datetime.date(2025, 1, 12), 'Ritmo cardíaco normal.', 'Dr. Luís Andrade')]
    
   
# **Criar o prompt**
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are an AI assistant that converts SQL database query results into natural language sentences. "
                   "Make sure to always include all details, especially the doctor in charge."
                    "Do not repeat the question and do not include follow-up prompts.\n\n"),
        
        ("user", f"""Question: {question}
    SQL Query: {sql_query}
    SQL Result: {result}
    
    Translate this SQL result into a short and clear response in Portuguese."""),
    ])

   #  **Converter para string no formato correto**
    formatted_prompt = f"""<|im_start|>system
    {prompt.format_messages()[0].content}<|im_end|>
    <|im_start|>user
    {prompt.format_messages()[1].content}<|im_end|>
    <|im_start|>assistant
    """
    
    #  **Executar a inferência**
    print("\n🔹 Gerando resposta...")
    
    generated_text = ""
    for chunk in llm.stream(formatted_prompt):
        print(chunk, end="", flush=True)  
        generated_text += chunk
    
    # **Formatar saída final**
    response = generated_text.strip()
    response = generated_text.replace("<|im_end|>", "").strip()
    return response


def is_visual_query(question: str) -> bool:
    visual_keywords = ["Quais","distribuição", "número", "quantos", "por dia", "por especialidade", "ao longo do tempo", "tendência"]
    return any(kw in question.lower() for kw in visual_keywords)


def process_medical_query(question,patient_id=None):
    sql_query = generate_query(question,patient_id=patient_id)
    sql_query2= sql_query.replace("<|eot_id|>", "").strip()
    print(sql_query2)
    result = execute_sql_query(sql_query)

    if isinstance(result, str):  # se for erro
        return {"tipo": "erro", "mensagem": sql_query2}

    if is_visual_query(question) and result and len(result[0]) == 2:
        # Retorna dados para gráfico
        return {
            "tipo": "grafico",
            "dados": result,
            "pergunta": question,
            "sql": sql_query
        }
    else:
        resposta = sql_result_to_natural_language(llm, question, sql_query, result)
        return {
            "tipo": "texto",
            "mensagem": resposta,
            "sql": sql_query
        }

        
def process_medical_query_patient(question,patient_id=None):
    sql_query = generate_query(question,patient_id=patient_id)
    sql_query2= sql_query.replace("<|eot_id|>", "").strip()
    print(sql_query2)
    result = execute_sql_query(sql_query)
    resposta = sql_result_to_natural_language(llm, question, sql_query2, result)
    dic= {"mensagem": resposta, "sql": sql_query}
    return dic

    
# execute_sql_query(sql_query)    
#sql_result_to_natural_language(question, result)