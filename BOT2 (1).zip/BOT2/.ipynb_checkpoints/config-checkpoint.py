# config.py

DB_CONFIG = {
    "host": "beneutral.di.uminho.pt",
    "port": "5432",
    "database": "mydatabase",
    "user": "myuser",
    "password": "mypassword"
}
